package gameElements;

public interface Eval {
	public float getEval(Player player, Board b);
	
}
