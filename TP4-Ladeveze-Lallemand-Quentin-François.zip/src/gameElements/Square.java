package gameElements;

public interface Square {	
	public Player getPlayer();
	public void setPlayer(Player p);
	public String toString();
	
}
